'use strict';
// Who Wants to Be a Grammar Millionaire? — zero-dependency server (Node 18+).
// Server-authoritative state, Server-Sent Events for real-time sync, JSON-file persistence.
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=+process.env.PORT||3000, PIN=process.env.HOST_PIN||'1234';
const Q=JSON.parse(fs.readFileSync(path.join(__dirname,'questions.json'),'utf8'));
const LADDER=[100,200,300,500,1000,2000,5000,10000,50000,1000000];
const DB=process.env.DB_FILE||path.join(__dirname,'data.json');
let games={}; try{games=JSON.parse(fs.readFileSync(DB,'utf8'))}catch(e){}
let st; const save=()=>{clearTimeout(st);st=setTimeout(()=>fs.writeFile(DB,JSON.stringify(games),()=>{}),200)};
const rid=n=>crypto.randomBytes(n).toString('hex'), now=()=>Date.now();
const clients=new Set();
const HELP_MS=30000, POLL_MS=30000;

function mkGame(secs){
  let code; do{code=Array.from({length:5},()=>'ABCDEFGHJKMNPQRSTUVWXYZ23456789'[crypto.randomInt(31)]).join('')}while(games[code]);
  return games[code]={code,hostToken:rid(16),secs,status:'lobby',q:-1,endsAt:0,paused:false,pausedLeft:0,polls:{},reqs:[],log:[],
    teams:[1,2,3,4,5,6].map(n=>({n,token:null,answers:{},hidden:{},life:{fifty:null,audience:null,phone:null},prize:0,correct:0,none:0,results:{}}))};
}
const online=(g,n)=>[...clients].some(c=>c.code===g.code&&c.team===n);
const log=(g,text,team)=>{g.log.push({t:now(),team:team||null,text});if(g.log.length>200)g.log.shift()};
const joined=g=>g.teams.filter(t=>t.token);
const pct=(p)=>{const v=Object.values(p.votes),n=v.length;return [0,1,2,3].map(i=>n?Math.round(100*v.filter(x=>x===i).length/n):0)};

function view(g,c){
  const q=g.q>=0?Q[g.q]:null, s=g.status, t=now(), open=s==='open';
  const showQ=q&&['open','locked','revealed'].includes(s), rev=s==='revealed';
  const v={code:g.code,status:s,q:g.q,secs:g.secs,paused:g.paused,now:t,ladder:LADDER,total:Q.length,
    left:open?(g.paused?g.pausedLeft:Math.max(0,g.endsAt-t)):0,
    question:showQ?{text:q.text,options:q.options,topic:q.topic}:null,
    teams:g.teams.map(x=>({n:x.n,joined:!!x.token,online:online(g,x.n),prize:x.prize,correct:x.correct,none:x.none,
      submitted:(open||s==='locked')?!!x.answers[g.q]:undefined,
      res:rev?x.results[g.q]:undefined,ans:rev&&x.answers[g.q]?x.answers[g.q].choice:undefined})),
    lifeCount:g.log.filter(l=>l.life).length};
  if(rev)v.reveal={correct:q.answer,explain:q.explain,why:q.why};
  const poll=g.polls[g.q];
  if(c.role==='host'){
    v.host={teams:g.teams.map(x=>({n:x.n,answer:x.answers[g.q]?x.answers[g.q].choice:null,life:{fifty:!!x.life.fifty,audience:!!x.life.audience,phone:!!x.life.phone}})),
      correct:q&&s!=='lobby'&&s!=='ready'?q.answer:null,reqs:g.reqs.filter(r=>true).slice(-12),log:g.log.slice(-40),
      poll:poll?{by:poll.by,closed:poll.closed,count:Object.keys(poll.votes).length}:null};
    v.hostQ=q&&s!=='lobby'?{text:q.text,options:q.options}:null;
  }else if(c.role==='team'){
    const x=g.teams[c.team-1],a=x.answers[g.q];
    const my=g.reqs.find(r=>r.q===g.q&&r.from===x.n), ask=g.reqs.find(r=>r.q===g.q&&r.helper===x.n&&r.status==='asked');
    v.me={n:x.n,answer:a?a.choice:null,hidden:x.hidden[g.q]||[],life:{fifty:!!x.life.fifty,audience:!!x.life.audience,phone:!!x.life.phone},
      prize:x.prize,correct:x.correct,none:x.none,result:x.results[g.q]||null,
      tally:poll&&poll.by===x.n&&poll.closed?pct(poll):null,pollOpen:!!(poll&&poll.by===x.n&&!poll.closed),
      phone:my?{status:my.status,helper:my.helper,advice:my.advice}:null,
      help:ask?{id:ask.id,from:ask.from,deadline:ask.deadline}:null};
    if(poll&&!poll.closed&&poll.by!==x.n&&poll.votes['T'+x.n]===undefined)v.vote={by:poll.by};
  }else if(c.role==='aud'){
    if(poll&&!poll.closed&&poll.votes['A'+c.voter]===undefined)v.vote={by:poll.by};
  }
  return v;
}
const send=(c)=>{const g=games[c.code];if(g)c.res.write('data:'+JSON.stringify(view(g,c))+'\n\n')};
const push=g=>{save();clients.forEach(c=>{if(c.code===g.code)send(c)})};
const err=(res,code,msg)=>{res.writeHead(code,{'Content-Type':'application/json'});res.end(JSON.stringify({error:msg}))};
const ok=(res,o)=>{res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify(o||{ok:true}))};

function reveal(g){
  const q=Q[g.q];
  g.teams.forEach(x=>{if(x.results[g.q])return;const a=x.answers[g.q];
    if(!a){x.results[g.q]='none';x.none++}
    else if(a.choice===q.answer){x.results[g.q]='ok';x.correct++;x.prize=LADDER[g.q]}
    else x.results[g.q]='bad'});
  g.status='revealed';log(g,'Answer revealed for question '+(g.q+1));
}
function tick(){
  const t=now();
  for(const g of Object.values(games)){let ch=false;
    if(g.status==='open'&&!g.paused&&t>=g.endsAt){g.status='locked';log(g,'Time is up — submissions closed');ch=true}
    const p=g.polls[g.q];if(p&&!p.closed&&(t>=p.end)){p.closed=true;log(g,'Audience vote for Team '+p.by+' closed',p.by);ch=true}
    g.reqs.forEach(r=>{if(r.status==='asked'&&t>=r.deadline){r.status='expired';r.tResp=t;log(g,'Team '+r.helper+' did not answer Team '+r.from+"'s call",r.from);ch=true}});
    if(ch)push(g)}
}
setInterval(tick,500);

function act(g,b){
  const isHost=b.token===g.hostToken, T=g.teams.find(x=>x.token&&x.token===b.token);
  if(!isHost&&!T)throw new Error('Not authorised');
  const q=g.q>=0?Q[g.q]:null, t=now(), open=g.status==='open'&&!g.paused&&t<g.endsAt;
  if(isHost){
    switch(b.type){
      case'start':if(g.status!=='lobby')throw new Error('Already started');if(!joined(g).length)throw new Error('No teams have joined yet');g.status='ready';log(g,'Game started');break;
      case'qstart':if(!['ready','revealed'].includes(g.status)||g.q>=Q.length-1)throw new Error('Cannot start a question now');
        g.q++;g.status='open';g.paused=false;g.endsAt=t+g.secs*1000;log(g,'Question '+(g.q+1)+' started');break;
      case'close':if(g.status!=='open')throw new Error('No open question');g.status='locked';g.paused=false;log(g,'Submissions closed by presenter');break;
      case'reveal':if(!['open','locked'].includes(g.status))throw new Error('Nothing to reveal');g.paused=false;reveal(g);break;
      case'pause':if(g.status!=='open'||g.paused)throw new Error('Cannot pause');g.paused=true;g.pausedLeft=Math.max(0,g.endsAt-t);log(g,'Paused');break;
      case'resume':if(!g.paused)throw new Error('Not paused');g.paused=false;g.endsAt=t+g.pausedLeft;log(g,'Resumed');break;
      case'end':if(g.status==='open'||g.status==='locked')reveal(g);g.status='final';log(g,'Competition ended');break;
      case'assign':{const r=g.reqs.find(r=>r.id===b.id);
        if(!r||r.status!=='pending')throw new Error('Request is not pending');
        const h=g.teams[b.helper-1];if(!h||!h.token)throw new Error('That team has not joined');
        if(h.n===r.from)throw new Error('A team cannot help itself');
        r.helper=h.n;r.status='asked';r.tAsk=t;r.deadline=t+HELP_MS;log(g,'Presenter asked Team '+h.n+' to help Team '+r.from,r.from);break}
      default:throw new Error('Unknown action');
    }
    return;
  }
  switch(b.type){
    case'answer':{if(!open)throw new Error('Submissions are closed');if(T.answers[g.q])throw new Error('Already submitted');
      const c=b.choice;if(![0,1,2,3].includes(c)||(T.hidden[g.q]||[]).includes(c))throw new Error('Invalid option');
      T.answers[g.q]={choice:c,t};log(g,'Team '+T.n+' locked in an answer',T.n);
      const j=joined(g);if(j.every(x=>x.answers[g.q])){g.status='locked';log(g,'All teams submitted')}break}
    case'fifty':{if(!open)throw new Error('Not available now');if(T.life.fifty)throw new Error('Already used');if(T.answers[g.q])throw new Error('Already submitted');
      const wrong=[0,1,2,3].filter(i=>i!==q.answer).sort(()=>Math.random()-.5).slice(0,2);
      T.hidden[g.q]=wrong;T.life.fifty={q:g.q,t};log(g,'Team '+T.n+' used 50:50',T.n);g.log[g.log.length-1].life=1;break}
    case'audience':{if(!open)throw new Error('Not available now');if(T.life.audience)throw new Error('Already used');if(T.answers[g.q])throw new Error('Already submitted');
      T.life.audience={q:g.q,t};g.polls[g.q]={by:T.n,votes:{},closed:false,end:t+POLL_MS};
      log(g,'Team '+T.n+' asked the audience',T.n);g.log[g.log.length-1].life=1;break}
    case'phone':{if(!open)throw new Error('Not available now');if(T.life.phone)throw new Error('Already used');if(T.answers[g.q])throw new Error('Already submitted');
      T.life.phone={q:g.q,t};g.reqs.push({id:rid(4),q:g.q,from:T.n,helper:null,status:'pending',tReq:t,tAsk:null,tResp:null,deadline:null,advice:null});
      log(g,'Team '+T.n+' requested Phone a Friend',T.n);g.log[g.log.length-1].life=1;break}
    case'help':{const r=g.reqs.find(r=>r.id===b.id);
      if(!r||r.helper!==T.n||r.status!=='asked'||t>=r.deadline)throw new Error('This request is no longer open');
      if(![0,1,2,3].includes(b.choice))throw new Error('Choose A, B, C or D');
      r.advice={choice:b.choice,text:String(b.text||'').slice(0,140)};r.status='answered';r.tResp=t;
      log(g,'Team '+T.n+' answered Team '+r.from+"'s call",r.from);break}
    default:throw new Error('Unknown action');
  }
}

const body=req=>new Promise(r=>{let d='';req.on('data',c=>{d+=c;if(d.length>1e5)req.destroy()});req.on('end',()=>{try{r(JSON.parse(d||'{}'))}catch(e){r({})}})});
http.createServer(async(req,res)=>{
  const u=new URL(req.url,'http://x'),p=u.pathname,qs=u.searchParams;
  try{
    if(req.method==='GET'&&p==='/api/events'){
      const g=games[(qs.get('code')||'').toUpperCase()];if(!g)return err(res,404,'Game not found');
      const role=qs.get('role'),tok=qs.get('token');const c={res,code:g.code,role,team:null,voter:String(qs.get('voter')||'').slice(0,32)};
      if(role==='host'){if(tok!==g.hostToken)return err(res,403,'Not authorised')}
      else if(role==='team'){const x=g.teams.find(x=>x.token&&x.token===tok);if(!x)return err(res,403,'Not authorised');c.team=x.n}
      else if(role!=='screen'&&role!=='aud')return err(res,400,'Bad role');
      res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive'});
      clients.add(c);send(c);req.on('close',()=>{clients.delete(c);const gg=games[c.code];if(gg)push(gg)});
      const hb=setInterval(()=>res.write(': hb\n\n'),15000);req.on('close',()=>clearInterval(hb));
      if(role==='team'||role==='host')push(g);return;
    }
    if(req.method==='GET'&&p==='/api/info'){const g=games[(qs.get('code')||'').toUpperCase()];if(!g)return err(res,404,'Game code not found');
      return ok(res,{teams:g.teams.map(x=>({n:x.n,joined:!!x.token})),status:g.status})}
    if(req.method==='POST'){
      const b=await body(req);const g=games[String(b.code||'').toUpperCase()];
      if(p==='/api/create'){if(b.pin!==PIN)return err(res,403,'Wrong presenter PIN');
        const secs=Math.min(300,Math.max(10,+b.secs||45));const ng=mkGame(secs);save();return ok(res,{code:ng.code,token:ng.hostToken})}
      if(!g)return err(res,404,'Game code not found');
      if(p==='/api/join'){const x=g.teams[(+b.team)-1];if(!x)return err(res,400,'Choose Team 1 to 6');
        if(x.token&&x.token!==b.token)return err(res,409,'Team '+x.n+' is already registered on another device');
        if(!x.token){x.token=rid(16);log(g,'Team '+x.n+' joined',x.n)}push(g);return ok(res,{token:x.token,team:x.n})}
      if(p==='/api/act'){b.type=String(b.type);act(g,b);push(g);return ok(res)}
      if(p==='/api/vote'){const poll=g.polls[g.q],voter=String(b.voter||'').slice(0,32);
        if(!poll||poll.closed||now()>=poll.end)throw new Error('No vote is open');
        const T=g.teams.find(x=>x.token&&x.token===b.token);const key=T?'T'+T.n:'A'+voter;
        if(T&&T.n===poll.by)throw new Error('Your team cannot vote on its own poll');
        if(!T&&!voter)throw new Error('Missing voter id');
        if(poll.votes[key]!==undefined)throw new Error('You already voted');
        if(![0,1,2,3].includes(b.choice))throw new Error('Invalid option');
        poll.votes[key]=b.choice;push(g);return ok(res)}
      return err(res,404,'Not found');
    }
    if(req.method==='GET'){const f=path.join(__dirname,'public',p==='/'?'index.html':path.normalize(p).replace(/^(\.\.[\/\\])+/,''));
      return fs.readFile(f,(e,d)=>{if(e){res.writeHead(404);return res.end('Not found')}
        res.writeHead(200,{'Content-Type':f.endsWith('.html')?'text/html; charset=utf-8':'application/octet-stream'});res.end(d)})}
    err(res,405,'Method not allowed');
  }catch(e){if(!res.headersSent)err(res,400,e.message)}
}).listen(PORT,()=>console.log('Grammar Millionaire on http://localhost:'+PORT+'  (presenter PIN: '+PIN+')'));
