# Who Wants to Be a Grammar Millionaire?
Zero-dependency Node 18+ app: server-authoritative state, real-time sync over Server-Sent Events, JSON-file persistence (`data.json`).

## Run
    HOST_PIN=4821 node server.js        # default PIN 1234, default port 3000
1. Laptop: open `http://<laptop-ip>:3000/?mode=host`, enter the PIN and the seconds per question, then create the session.
2. Projector: open the "Projector" link shown on the dashboard in a second window and put it fullscreen (F11).
3. Phones: scan/type the "Teams" link, enter the code, pick Team 1-6.
4. Extra students can open the "Audience" link to vote in Ask the Audience.
Phones and laptop must reach the laptop's IP (same Wi-Fi, no client isolation) or use a deployed URL.

## Deploy
Any Node host (Render, Railway, Fly.io, a VPS): start command `node server.js`, set `HOST_PIN` and keep a persistent disk (or set `DB_FILE`). Use HTTPS; no build step. SSE needs a proxy that does not buffer responses.

## Rules as implemented
- Teams stay in the game after a wrong answer. Prize = ladder value of the team's most recent correct question; ranking = correct answers, then prize, then fewer unanswered.
- Submissions close at zero, when the presenter closes them, or when every joined team has submitted. Late and duplicate submissions are rejected.
- Phone a Friend: the helper has 30 s; an unanswered call expires and the lifeline is still spent. Ask the Audience: a 30 s poll; the requester sees percentages when it closes (voters: other teams + audience page).
- Questions live in `questions.json` (editable; keep four options, `answer` index 0-3).

## Classroom test (do this before the day)
1. Laptop = presenter, a second laptop window = projector, six phones (or six browser profiles) = Teams 1-6, one more as audience.
2. Join all six; try joining Team 3 twice (must be refused). Start the game, set a short timer (15 s).
3. All six see the same question at the same moment; refresh one phone mid-question (timer and lifelines must survive).
4. Use each lifeline once on different teams; try to reuse one (button disabled/refused).
5. Let one team time out; reveal; check the projector, scoreboard and dashboard agree.
6. Restart `node server.js` mid-game; presenter and teams reconnect automatically.
7. Check the projector from the back of the room, and sound after the first tap on each device.
